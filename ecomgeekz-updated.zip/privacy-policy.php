
<?php include("include/header.php"); ?>




<body class="hompg">


<?php include("include/menu.php"); ?>




    <!-- header strat -->

<!-- body -->

<!-- banner-main-sec -->
<!--<section class="banner-main-sec">-->
<!--    <div class="container">-->
<!--        <div class="row al-flex-end">-->
<!--            <div class="col-lg-6">-->
<!--                <ul class="list-page">-->
<!--                    <li><a href="https://ecomgeekz.com/">Home</a></li>-->
<!--                    <li><a href="javascript:(void)" class="active">Privacy Policy</a></li>-->
<!--                </ul>-->
<!--                <h2>Privacy Policy</h2>-->
<!--            </div>-->
<!--            <div class="col-lg-3 offset-lg-1">-->
              
<!--            </div>-->
<!--        </div>-->
<!--        <div class="row">-->
<!--            <div class="col-lg-12">-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Culpa aut, porro sunt voluptas magni incidunt ut amet cum nihil hic enim, quo voluptatibus iste ad harum iure consectetur veritatis et? Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Debitis, magnam autem, quae repellat non porro pariatur in, ullam nesciunt deserunt saepe omnis voluptatibus eveniet illo error minima harum assumenda ad? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ullam, culpa a quas. Quisquam, laudantium necessitatibus ex, sed sequi quasi obcaecati, architecto amet assumenda, magnam quidem fuga expedita iusto beatae tempora! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos dolorem asperiores repellat voluptatum beatae iste id, illo iure modi quae maiores temporibus mollitia repudiandae praesentium omnis quas sint recusandae natus.</p>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->
<!-- banner-sec -->

<section class="termswrp">
   <div class="container">
       <div class="row">
           <div class="col-md-12 text-left">
               <div class="txtwrp">
                   <h2>Privacy Policy</h2>
                   
                   
                   <p><strong>1. Introduction</strong></p>
                   <p class="themes-p" style="padding: 0 0 0 !important;">At EcomGeekz, accessible from https://ecomgeekz.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains information about the types of information LetsEcom LLC, DBA EcomGeekz collects and records and how we use it. </p>
                   <p class="themes-p" style="padding: 0 0 0 !important;">By accessing or using our services, you signify that you have read, understood, and agree to our collection, storage, use, and disclosure of your personal information as described in this Privacy Policy. If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
</p>
                   
                   <hr>
               </div>
           </div>
       </div>
      <div class="row">
         <div class="txtwrp">
             <p><strong>2. Information We Collect</strong></p>
              
               <p><span><b>2.1. Personal Information:</b> When you interact with us, we may collect personal information that you voluntarily provide, such as:</span></p>
                <ul>
                 <li>Contact Information: Name, email address, phone number, postal address.</li>
                 
                  <li>Account Information: Username, password, and other registration details.</li>
                  
                   <li>Payment Information: Credit card number, billing address, and other financial information.</li>
                   
                    <li>Business Information: Business name, industry, and related details for services such as business formation.</li>
                </ul>
                <p><span><b>2.2. Automatically Collected Information:</b> We may also collect information automatically when you visit our website or use our services, including:</span></p>
                <ul>
                 <li>Usage Information: IP address, browser type, operating system, referring URLs, pages viewed, and the dates/times of your visits.</li>
                 
                  <li>Cookies and Similar Technologies: Information collected through cookies, web beacons, and other tracking technologies.</li>
                </ul>  
                  <p><span><b>2.3. Log Files:</b> LetsEcom LLC, DBA EcomGeekz follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this, and it is part of hosting services' analytics. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any personally identifiable information. The purpose of the information is to analyze trends, administer the site, track users' movement on the website, and gather demographic information.</span></p>
                  
                  <p><span><b>2.4. Cookies and Web Beacons:</b> Like any other website, LetsEcom LLC, DBA EcomGeekz uses "cookies". These cookies store information, including visitors' preferences and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.</span></p>

               <p><strong>3. How We Use Your Information</strong></p>
               <p><span>We use the information we collect for various purposes, including:</span></p>
               
               <ul>
                      <li>To provide, operate, and maintain our services.</li>
                    
                      <li>To process your transactions and manage your orders.</li>
                    
                      <li>To communicate with you, including responding to your inquiries and sending service-related notifications.</li>
                    
                      <li>To personalize your experience and present relevant content and offers.</li>
                    
                      <li>To improve our website, services, and user experience.</li>
                    
                      <li>To enforce our terms, conditions, and policies.</li>
                    
                      <li>To protect against fraudulent or unauthorized activity.</li>
                    
                    </ul>
               
            <p><strong>4. How We Use Your Information</strong></p>
               <p><span>We may share your information with third parties in the following circumstances:</span></p>
               
               <ul>
                      <li><strong>SMS opt-in or phone numbers for the purpose of SMS are not being shared with any third party and affiliate company for marketing purposes.</strong></li>
                    </ul>
               
               
               <p><strong>5. Security of Your Information</strong></p>
               <p><span>We use administrative, technical, and physical security measures to help protect your personal information. However, no data transmission over the Internet or wireless network can be guaranteed as 100% secure. Therefore, while we strive to protect your personal information, you acknowledge that there are security and privacy limitations inherent to the Internet which are beyond our control.</span></p>
               
        <p><strong>6. Third-Party Services and Advertising</strong></p>
               <p><span><b>6.1. Google DoubleClick DART Cookie:</b> Google is a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based on their visit and other sites on the Internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL: https://policies.google.com/ technologies/ads.</span></p>
               
                <p><span><b>6.2. Our Advertising Partners:</b> Some of the advertisers on our site may use cookies and web beacons. Our advertising partners are listed below. Each has its own privacy policy on user data. For easier access, we hyperlinked to their Privacy Policies below.</span></p>
               <ul>
                      <li>Google: https://policies.google.com/technologies/ads</li> </ul>
                      
                      <p><strong>7. Privacy Policies of Advertising Partners</strong></p>
               <p><span>You may consult this list to find the Privacy Policy for each of the advertising partners of LetsEcom LLC, DBA EcomGeekz Third-party ad servers or ad networks use technologies like cookies, JavaScript, or Web Beacons in their respective advertisements and links that appear on LetsEcom LLC, DBA EcomGeekz, which are sent directly to users' browsers. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit. Note that LetsEcom LLC, DBA EcomGeekz has no access to or control over these cookies that third-party advertisers use.</span></p>
                      
                      
                    <p><strong>8. Third-Party Privacy Policies</strong></p>
               <p><span>LetsEcom LLC, DBA EcomGeekz's Privacy Policy does not apply to other advertisers or websites. Thus, we advise you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. These policies may include their practices and instructions about how to opt out of certain options. You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers' respective websites. What Are Cookies?</span></p>
               
               <p><strong>9. Children's Information</strong></p>
               <p><span>Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity. LetsEcom LLC, DBA EcomGeekz does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately. We will do our best efforts to promptly remove such information from our records.</span></p>
                      
                   <p><strong>10. Online Privacy Policy Only</strong></p>
               <p><span>This Privacy Policy applies only to our online activities and is valid for visitors to our website and social media platforms regarding the information that they share and/or collect in LetsEcom LLC, DBA EcomGeekz This policy is not applicable to any information collected offline or via channels other than this website and all social media channels.</span></p>   
                      
                      
                  <p><strong>11. Your Privacy Rights</strong></p>
               <p><span>Depending on your location, you may have the following rights regarding your personal information:</span></p>
               
               <ul>
                      <li>Access: You may request access to the personal information we hold about you.</li>
                    
                      <li>Correction: You may request that we correct any inaccuracies in your personal information.</li>
                    
                      <li>Deletion: You may request that we delete your personal information, subject to certain exceptions.</li>
                    
                      <li>Opt-Out: You may opt-out of receiving marketing communications from us at any time.</li>
                      
                      <li>To exercise any of these rights, please contact us using the contact information provided below.</li>
                    </ul>    
                      
                  
               
                <p><strong>12. Consent</strong></p>
               <p><span>By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.</span></p> 
               
               <p><strong>13. Privacy Policy Changes</strong></p>
               <p><span>LetsEcom LLC, DBA EcomGeekz is always improving our Services. As our Services evolve, we may update or amend this Privacy Policy. If we modify this Privacy Policy, we will post the revised Privacy Policy online. The revised Privacy Policy will be effective immediately at the time of posting, unless a later effective date is expressly stated therein. We will also revise the “Last updated” date stated below.</span></p> 
               <p><span>Should any modification materially change how we use your Personal Information, we will provide notice online prior to the effective date of the change.</span></p> 
               
                <p><span>It is your responsibility to periodically review this Privacy Policy. Users are bound by any changes to this Privacy Policy by using our Services after such changes have been first posted. If you do not agree to the new posted Privacy Policy, your only remedy is to discontinue use of the website.</span></p> 
                   
            <p><strong>14. Contact Information</strong></p>
               <p><span>If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:</span></p> 
               
               <p><span>EcomGeekz<br>
               
               Email: hello@ecomgeekz.com<br>
               Phone: +1 (855) 666-5880</span></p>
               
                <p><strong>15. SMS Compliance</strong></p>
               <p><span>By opting into SMS, you are agreeing to receive SMS messages from EcomGeekz. This includes SMS messages for appointment scheduling, appointment reminders, project updates, and billing notifications. Message frequency varies. Message and data rates may apply. See privacy policy. Message HELP for help. Reply STOP to any message to opt out. SMS consent is not shared with third parties for marketing purposes.</span></p> 
               
               <p><span>By using our services, you acknowledge that you have read and understood this Privacy Policy and agree to our collection, use, and disclosure of your personal information as described herein.</span></p> 
               
                <p><span>This privacy policy is intended to comply with applicable privacy laws and regulations, including but not limited to the General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA). If you have any specific legal requirements or questions, we recommend consulting with a legal professional.</span></p> 
                   
               
               
         </div>
      </div>
   </div>
</section>


<!-- body -->


<?php include("include/footer.php"); ?>