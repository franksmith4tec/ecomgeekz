
<?php include("include/header.php"); ?>



<body class="hompg">



<?php include("include/menu.php"); ?>




    <!-- header strat -->

<!-- body -->
<!-- banner-main-sec -->
<section class="banner-main-sec" style="height:100vh">
    <img src="assets/images/marketing-Main-Banner.jpg" class="banne-img" alt="img" />
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
             
                <h1>Thank You!</h1>
                <p>Begin your journey to success as you effortlessly launch and scale your marketing agency. Our expert guidance ensures you target monthly revenues of up to $10,000 with clarity and ease.</p>
               
                <a href="index.php" class="themes-btn">Back to Home</a>
              
            </div>
            <div class="col-lg-6"></div>
        </div>
    </div>
</section>
<!-- banner-sec -->



<?php include("include/cta-all.php"); ?>
<?php include("include/footer.php"); ?>